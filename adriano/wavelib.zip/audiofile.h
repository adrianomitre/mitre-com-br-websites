#include "data_structures.h"

enum {MIN_NUMBER_OF_CHANNELS = 1, MAX_NUMBER_OF_CHANNELS = 2};
enum {MIN_BIT_DEPTH = 8, MAX_BIT_DEPTH = 16};
enum {MIN_SAMPLE_RATE = 8000, MAX_SAMPLE_RATE = 48000};

unsigned char verify_extension (const char* name, const char* extension);

signed char open_audiofile(Audio_Stream* stream);
signed char create_audiofile(Audio_Stream* output);
signed char close_audiofile(Audio_Stream* stream);
short read_wav_header(Audio_Stream* stream);
short write_wav_header(const Audio_Stream *stream);

float c8_to_float(const unsigned char sample);
float c16_to_float(const unsigned char sample[2]);

int round_float_to_8_bits_int(const float val);
int round_float_to_16_bits_int(const float val);
int round_float_to_int(const float val);

void* emalloc(const size_t size);

Audio_Stream* alloc_audiostream();
signed char write_audiofile(Audio_Stream* input_stream);

void cfloat_to_16(const float sample, unsigned char byte[2]);
void cfloat_to_8(const float sample, unsigned char byte[1]);

/* THE FOLLOWING ARE THE MOST USEFUL FUNCTIONS */

Audio_Stream* create_audiostream(unsigned char bit_depth, unsigned char num_of_channels,
				unsigned int sample_rate, unsigned long total_num_of_samples);

int save_audiofile();

void free_audiostream(Audio_Stream* stream);

Audio_Stream* load_audiofile(char *input_filename);

Audio_Stream* duplicate_audiostream(const Audio_Stream* src, int n_pad);
