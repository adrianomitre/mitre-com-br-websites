#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>

#include "audiofile.h"
#include "numeric_constants.h"

#ifdef EBUG
#define DEBUG(A) A
#else
#define DEBUG(A)
#endif

/********************************************************************************************/
/* VERIFY_EXTENSION                                                                         */
/********************************************************************************************/
/* case insensitive */
unsigned char verify_extension (const char* name, const char* extension)
{
    unsigned char ext_len = strlen(extension), i;
    unsigned short name_len = strlen(name);

    for (i = 1; i <= ext_len; i++)
    	if (tolower(name[name_len - i]) != tolower(extension[ext_len - i])) return FALSE;

    return TRUE;
}

/********************************************************************************************/
/* OPEN_AUDIOFILE                                                                           */
/********************************************************************************************/
signed char open_audiofile(Audio_Stream* stream)
{
    if ((stream->file_pointer = fopen(stream->file_name, "rb")) == NULL)
    {
        fprintf(stderr, "Error opening '%s'.\n", stream->file_name);
        return ERROR;
    }

    return OK;
}

/********************************************************************************************/
/* CREATE_AUDIOFILE                                                                         */
/********************************************************************************************/
signed char create_audiofile(Audio_Stream* result)
{
	if (!(result->file_pointer = fopen (result->file_name, "wb")))
    {
        fprintf(stderr, "\nError creating file %s.\n\n", result->file_name);
        exit(-1);
    }

		return OK;
}

/********************************************************************************************/
/* CLOSE_AUDIOFILE                                                                          */
/********************************************************************************************/
signed char close_audiofile(Audio_Stream* stream)
{
    if (fclose(stream->file_pointer) == EOF)
        return ERROR;

    stream->file_pointer = NULL;

    return OK;
}


/********************************************************************************************/
/* READ_WAV_HEADER                                                                          */
/********************************************************************************************/
short read_wav_header(Audio_Stream *stream)
{
    long unsigned l_temp = 0, bytes_per_second = 0, bytes_per_sample = 0;
    int unsigned i_temp = 0;
    char s_temp[5], s_ref[5];
    unsigned char t_sample[32];

    s_temp[4] = s_ref[4] = '\0';

    /* block identifier */
    fread(&s_temp, 4, 1, stream->file_pointer);
    strcpy (s_ref, "RIFF");
    if (strcmp(s_temp, s_ref))
    {
        fprintf(stderr, "Error reading input WAV header (RIFF).\n");
        return ERROR;
    }

    /* block size: size of header block (36) + size of samples block
        (number of samples * number of channels * byte depth) */
    l_temp = 0;
    fread(&l_temp, 4, 1, stream->file_pointer);

    /* block identifier */
    fread(&s_temp, 4, 1, stream->file_pointer);
    strcpy (s_ref, "WAVE");
    if (strcmp(s_temp, s_ref))
    {
        fprintf(stderr, "Error reading input WAV header (WAVE).\n");
        return ERROR;
    }

    /* block identifier */
    fread(&s_temp, 4, 1, stream->file_pointer);
    strcpy (s_ref, "fmt ");
    if (strcmp(s_temp, s_ref))
    {
        fprintf(stderr, "Error reading input WAV header (fmt ).\n");
        return ERROR;
    }

    /* format block size */
    l_temp = 0;
    if (fread(&l_temp, 4, 1, stream->file_pointer) < 1)
    {
        fprintf(stderr, "Error reading format block size (pos %ld)\n",
        														ftell(stream->file_pointer));
    }
    if (l_temp != 16)
    {
        fprintf(stderr, "Unsupported WAV format (format block size %ld).\n", l_temp);
        return ERROR;
    }

    /* sample format (PCM = 1) */
    i_temp = 0;
    fread(&i_temp, 2, 1, stream->file_pointer);
    if (i_temp != 1)
    {
        fprintf(stderr, "Unsupported WAV format (sample format = %d).\n", i_temp);
        return ERROR;
    }

    /* number of channels */
    i_temp = 0;
    fread(&i_temp, 2, 1, stream->file_pointer);
    if (i_temp < MIN_NUMBER_OF_CHANNELS || i_temp > MAX_NUMBER_OF_CHANNELS)
    {
        fprintf(stderr, "Unsupported WAV format (number of channels).\n");
        return ERROR;
    }
    stream->num_of_channels = i_temp;

    /* sample rate */
    l_temp = 0;
    fread(&l_temp, 4, 1, stream->file_pointer);
    if (l_temp < MIN_SAMPLE_RATE || l_temp > MAX_SAMPLE_RATE)
    {
        fprintf(stderr, "Unsupported WAV format (sample rate).\n");
        return ERROR;
    }
    stream->sample_rate = l_temp;

    /* bytes per second (sample rate * number of channels * byte depth) */
    fread(&bytes_per_second, 4, 1, stream->file_pointer);

    /* total number of bytes per sample (number of channels * byte depth) */
    fread(&bytes_per_sample, 2, 1, stream->file_pointer);

    /* bit depth */
    i_temp = 0;
    fread(&i_temp, 2, 1, stream->file_pointer);
    stream->bit_depth = i_temp;
    stream->byte_depth = (i_temp/8);

    if (bytes_per_second != stream->sample_rate * stream->num_of_channels
    																	* stream->byte_depth)
    {
        fprintf(stderr, "Inconsistent WAV header (bytes per second).\n");
        return ERROR;
    }
    if (bytes_per_sample != stream->num_of_channels * stream->byte_depth)
    {
        fprintf(stderr, "Inconsistent WAV header (bytes per sample).\n");
        return ERROR;
    }

    /* block identifier */
    fread(&s_temp, 4, 1, stream->file_pointer);
    strcpy (s_ref, "data");
    if (strcmp(s_temp, s_ref))
    {
        fprintf(stderr, "Error reading input WAV header (data).\n");
        return ERROR;
    }

    /* samples block size (number of samples * number of channels * byte depth) */
    l_temp = 0;
    fread(&l_temp, 4, 1, stream->file_pointer);
    stream->total_num_of_samples = l_temp / (stream->num_of_channels * stream->byte_depth);

    /* ensures that the state 'samples block size' correctly reflects reality */
    fseek(stream->file_pointer, (stream->total_num_of_samples - 1)
    							* (stream->byte_depth * stream->num_of_channels), SEEK_CUR);
    if (fread(t_sample, stream->byte_depth * stream->num_of_channels,
    			1, stream->file_pointer) == 0)
    {
        fprintf(stderr, "Invalid samples block size (file is smaller than stated in "
				        "the RIFF WAVE header).\n");
        return( ERROR );
    }
    if (fread(t_sample, stream->byte_depth * stream->num_of_channels,
    			1, stream->file_pointer) != 0)
    {
        fprintf(stderr, "Invalid samples block size (file is bigger than stated in "
				        "the RIFF WAVE header).\n");
        return( ERROR );
    }

    /* place the stream at the beginning of the sample block */
    fseek(stream->file_pointer, 44L, SEEK_SET);

    return OK;
}

/********************************************************************************************/
/* C8_TO_FLOAT                                                                              */
/********************************************************************************************/
float c8_to_float(const unsigned char sample)
{
	return ((float)sample - 128);
}

/********************************************************************************************/
/* C16_TO_FLOAT                                                                             */
/********************************************************************************************/
float c16_to_float(const unsigned char sample[2])
{
    if (sample[1] & 128)
        return (float)(((sample[0] + (sample[1] << 8)) - 1) ^ 0xFFFF) * (-1.0);
    else
        return (float)(sample[0] + (sample[1] << 8));
}

/********************************************************************************************/
/* CFLOAT_TO_16                                                                             */
/********************************************************************************************/
void cfloat_to_16(const float sample, unsigned char byte[2])
{
  int quantized = round_float_to_16_bits_int(sample);

	if (quantized < 0)
			{
      int temp = ~(-quantized) + 1;
			byte[1] = temp >> 8;
			byte[0] = temp & 255;
			}
	else
			{
			byte[1] = quantized >> 8;
			byte[0] = quantized & 255;
			}
}

/********************************************************************************************/
/* CFLOAT_TO_8                                                                              */
/********************************************************************************************/
void cfloat_to_8(const float sample, unsigned char byte[1])
{
  int quantized = round_float_to_16_bits_int(sample);

	byte[0] = (quantized >> 24) + 128;
}


/********************************************************************************************/
/* ROUND_FLOAT_TO_8_BITS_INT                                                                */
/********************************************************************************************/
int round_float_to_8_bits_int(const float val)
{
  if (val <= -128) return -128;

  if (val >= 127) return 127;

  {
    const int floor_val = (int)val;

    return floor_val + ( (val - (float)floor_val) >= 0.5 ? 1 : 0);
  }
}

/********************************************************************************************/
/* ROUND_FLOAT_TO_16_BITS_INT                                                               */
/********************************************************************************************/
int round_float_to_16_bits_int(const float val)
{
  if (val <= -32768) return -32768;

  if (val >= 32767) return 32767;

  {
    const int floor_val = (int)val;

    return floor_val + ( (val - (float)floor_val) >= 0.5 ? 1 : 0);
  }
}
/********************************************************************************************/
/* ROUND_FLOAT_TO_INT                                                                       */
/********************************************************************************************/
int round_float_to_int(const float val)
{
	const int floor_val = (int)val;

	return floor_val + ( (val - (float)floor_val) >= 0.5 ? 1 : 0);
}

/********************************************************************************************/
/* EMALLOC                                                                                  */
/********************************************************************************************/
void* emalloc(const size_t size)
{
    void* p;

    if ( ( p = malloc(size) ) != NULL )
    	return p;

    fprintf(stderr, "Error allocating memory. Aborting...\n");
    exit ( ERROR );
}

/********************************************************************************************/
/* READ_AUDIOFILE                                                                           */
/********************************************************************************************/
signed char read_audiofile(Audio_Stream* input_stream)
{
  const unsigned char num_of_channels = input_stream->num_of_channels,
      bytes_per_sample = input_stream->byte_depth * input_stream->num_of_channels;
  unsigned int i, j;
  unsigned char c, *raw_data;
  unsigned long total_num_of_samples = input_stream->total_num_of_samples;
  FILE *fp = input_stream->file_pointer;

  if ( feof(fp) || ferror(fp) ) return ERROR;

  input_stream->samples = (float**) emalloc(sizeof(float*) * num_of_channels);
  for (c = 0; c < num_of_channels; c++) {
    input_stream->samples[c] = (float*) emalloc(sizeof(float) * total_num_of_samples);
  }

  raw_data = (unsigned char*)emalloc(sizeof(unsigned char)*(total_num_of_samples * bytes_per_sample));

  fread(raw_data, bytes_per_sample, total_num_of_samples, fp);

  if (input_stream->bit_depth == 8)
  {
    for (c = 0; c < num_of_channels; c++)
      for (i = 0, j = c; i < total_num_of_samples; i++, j += bytes_per_sample)
        input_stream->samples[c][i] = c8_to_float(raw_data[j]);
  }
  else if (input_stream->bit_depth == 16)
  {
    for (c = 0; c < num_of_channels; c++)
      for (i = 0, j = 2*c; i < total_num_of_samples; i++, j += bytes_per_sample)
        input_stream->samples[c][i] = c16_to_float(&raw_data[j]);
  }

  free(raw_data);

  return OK;
}

/********************************************************************************************/
/* WRITE_WAV_HEADER                                                                         */
/********************************************************************************************/
short write_wav_header (const Audio_Stream *stream)
{
    long unsigned l_temp;
    int unsigned i_temp;

    /* block identifier */
    fprintf(stream->file_pointer, "RIFF");

    /* block size: size of header block (36) + size of samples block
        (number of samples * number of channels * byte depth) */
    l_temp = 36 + (stream->total_num_of_samples
                   * stream->num_of_channels * stream->byte_depth);
    fwrite(&l_temp, 4, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "block size: %ld\n", l_temp);)

    /* block identifier */
    fprintf(stream->file_pointer, "WAVE");

    /* block identifier */
    fprintf(stream->file_pointer, "fmt ");

    /* format block size */
    l_temp = 16;
    fwrite(&l_temp, 4, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "format block size: %ld\n", l_temp);)

    /* sample format (PCM  = 1) */
    i_temp = 1;
    fwrite(&i_temp, 2, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "sample format: %d\n", i_temp);)

    /* number of channels */
    i_temp = stream->num_of_channels;
    fwrite(&i_temp, 2, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "number of channels: %d\n", i_temp);)

    /* sample rate */
    l_temp = stream->sample_rate;
    fwrite(&l_temp, 4, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "sample rate: %ld\n", l_temp);)

    /* bytes per second (sample rate * number of channels * byte depth) */
    l_temp = stream->sample_rate * stream->num_of_channels * stream->byte_depth;
    fwrite(&l_temp, 4, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "bytes per second: %ld\n", l_temp);)

    /* total number of bytes per sample (number of channels * byte depth) */
    i_temp = stream->num_of_channels * stream->byte_depth;
    fwrite(&i_temp, 2, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "total number of bytes per sample: %ld\n", l_temp);)

    /* bit depth */
    i_temp = stream->bit_depth;
    fwrite(&i_temp, 2, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "bit depth: %d\n", i_temp);)

    /* block identifier */
    fprintf(stream->file_pointer, "data");

    /* samples block size (number of samples * number of channels * byte depth) */
    l_temp = stream->total_num_of_samples * stream->num_of_channels * stream->byte_depth;
    fwrite(&l_temp, 4, 1, stream->file_pointer);
    DEBUG(fprintf(stderr, "samples block size: %ld\n", l_temp);)

    return 0; /* USAR REALMENTE O CONTROLE DE ERROS */
}

/********************************************************************************************/
/* WRITE_AUDIOFILE                                                                          */
/********************************************************************************************/
signed char write_audiofile(Audio_Stream* result_stream)
{
	int i,c;
	unsigned char *buffer;

	int buf_size = result_stream->byte_depth*result_stream->num_of_channels*result_stream->total_num_of_samples;

	buffer = (unsigned char*) emalloc ( (sizeof(unsigned char)) * buf_size );

	if ( result_stream->bit_depth == 16 )
	{
		for ( i = 0; i < result_stream->total_num_of_samples; i++ )
		{
			for ( c = 0; c < result_stream->num_of_channels; c++ )
			{
				cfloat_to_16(result_stream->samples[c][i], buffer + i*result_stream->num_of_channels*result_stream->byte_depth + c*result_stream->byte_depth);
			}
		}
	}

	if ( result_stream->bit_depth == 8 )
	{
		for ( i = 0; i < result_stream->total_num_of_samples; i++ )
		{
			for ( c = 0; c < result_stream->num_of_channels; c++ )
			{
				cfloat_to_8(result_stream->samples[c][i], buffer + i*result_stream->num_of_channels*result_stream->byte_depth + c*result_stream->byte_depth);
			}
		}
	}

	if (fwrite(buffer, buf_size, 1, result_stream->file_pointer) != 1) return ERROR;
	free(buffer);
	return(OK);
}

/********************************************************************************************/
/* ALLOC_AUDIOSTREAM                                                                        */
/********************************************************************************************/
Audio_Stream* alloc_audiostream()
{
	Audio_Stream *result;
	result = (Audio_Stream*) emalloc ( sizeof(Audio_Stream) );
	result->num_of_channels = 0;
	result->total_num_of_samples = 0;
	result->file_pointer = NULL;
	result->samples = NULL;

	return(result);
}

/********************************************************************************************/
/* CREATE_AUDIOSTREAM                                                                       */
/********************************************************************************************/
Audio_Stream* create_audiostream(unsigned char bit_depth, unsigned char num_of_channels,
				unsigned int sample_rate, unsigned long total_num_of_samples)
{
	unsigned char c;
	unsigned long i;
	Audio_Stream *result;

	result = alloc_audiostream();
	result->sample_rate = sample_rate;
	result->bit_depth = bit_depth;
	result->byte_depth = bit_depth/8;
	result->num_of_channels = num_of_channels;
	
	result->samples = (float**) emalloc(sizeof(float*) * num_of_channels);
	for (c = 0; c < num_of_channels; c++) {
		result->samples[c] = (float*) emalloc(sizeof(float) * total_num_of_samples);
		for (i = 0; i < total_num_of_samples; i++) {
			result->samples[c][i] = 0.0;
		}
	}
	result->total_num_of_samples = total_num_of_samples;

	return(result);
}

/********************************************************************************************/
/* FREE_AUDIOSTREAM                                                                         */
/********************************************************************************************/
void free_audiostream(Audio_Stream* stream)
{
	unsigned char c;
	
	if (stream->file_pointer != NULL)
		close_audiofile(stream);

	if (stream->samples != NULL) {
		for (c = 0; c < stream->num_of_channels; c++) {
			if (stream->samples[c] != NULL) {
				free(stream->samples[c]);
			}
		}
	}
	free(stream);
}

/********************************************************************************************/
/* DUPLICATE_AUDIOSTREAM                                                                    */
/********************************************************************************************/
/* creates an Audio_Stream of length src->total_num_of_samples + n_pad,
   copies the samples of src to it,
   set the n_pad last samples to zero,
   and returns a pointer to it. */
Audio_Stream* duplicate_audiostream(const Audio_Stream* src, int n_pad)
{
	int i,j;
	Audio_Stream* new;

	new = alloc_audiostream();

	new->samples = (float**) emalloc ( sizeof(float*) * src->num_of_channels );
	for ( i = 0; i < src->num_of_channels; i++ )
		new->samples[i] = (float*) emalloc ( sizeof(float) * (src->total_num_of_samples + n_pad) );

	for ( i = 0; i < src->num_of_channels; i++ )
		for ( j = 0; j < src->total_num_of_samples; j++ )
			new->samples[i][j] = src->samples[i][j];

	for ( i = 0; i < src->num_of_channels; i++ )
		for ( j = src->total_num_of_samples; j < src->total_num_of_samples + n_pad; j++ )
			new->samples[i][j] = 0;

	new->sample_rate = src->sample_rate;
	new->bit_depth = src->bit_depth;
	new->byte_depth = src->byte_depth;
	new->total_num_of_samples = src->total_num_of_samples + n_pad;
	new->num_of_channels = src->num_of_channels;
	new->file_pointer = NULL;

	return(new);
}
/********************************************************************************************/
/* LOAD_AUDIOFILE                                                                           */
/********************************************************************************************/
Audio_Stream* load_audiofile(char *filename)
{
	Audio_Stream *input;
	input	= alloc_audiostream();
	strncpy(input->file_name, filename, FILENAME_MAX);
	if (open_audiofile(input) != OK) return NULL;
	if (read_wav_header(input) != OK) return NULL;
	if (read_audiofile(input) != OK) return NULL;
	if (close_audiofile(input) != OK) return NULL;
	return(input);
}

/********************************************************************************************/
/* SAVE_AUDIOFILE                                                                           */
/********************************************************************************************/
int save_audiofile (Audio_Stream* result, char* filename)
{
	strncpy(result->file_name,filename,FILENAME_MAX);
	if (create_audiofile(result) != OK ) return ERROR;
	if (write_wav_header(result) != OK) return ERROR;

	{
		/* AMPLITUDE NORMALIZATION */
		float abs_max = 1, abs_curr_val, norm_factor;
		int c,n;

		for ( c = 0; c < result->num_of_channels; c++ )
		{
			for ( n = 0; n < result->total_num_of_samples; n++ )
			{
				abs_curr_val = ( result->samples[c][n] >= 0 ? result->samples[c][n] : -1.0 * result->samples[c][n] );
				if ( abs_curr_val > abs_max )
					abs_max = abs_curr_val;
			}
		}

		norm_factor = (pow(2, result->bit_depth - 1) - 1) / abs_max;

		for ( c = 0; c < result->num_of_channels; c++ )
			for ( n = 0; n < result->total_num_of_samples; n++ )
					result->samples[c][n] = result->samples[c][n] * norm_factor;
	}

	if (write_audiofile(result) != OK) return ERROR;
	if (close_audiofile(result) != OK) return ERROR;
	return(OK);
}
