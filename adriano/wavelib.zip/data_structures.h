#ifndef _DATA_STRUCTURES_H_
#define _DATA_STRUCTURES_H_

#include <stdio.h> /* needed because of FILENAME_MAX */
#include "complex.h"

typedef enum {FALSE, TRUE} Boolean;

typedef struct t_audio_stream
{
    unsigned int sample_rate;
    unsigned char bit_depth;
    unsigned char byte_depth;
    unsigned char num_of_channels;
    unsigned long total_num_of_samples; /* per channel */
    char file_name[FILENAME_MAX];
    FILE* file_pointer;
    float **samples;
}
Audio_Stream;

#endif /* _DATA_STRUCTURES_H_ */
