#ifndef _NUMERIC_CONSTANTS_H_
#define _NUMERIC_CONSTANTS_H_

enum {OFF, ON};
enum {DOWN, UP};
enum {OK, ERROR};

#endif
