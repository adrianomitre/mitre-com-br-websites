#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "data_structures.h"
#include "numeric_constants.h"
#include "audiofile.h"

int main (int argc, char **argv) 
{
	unsigned long i;
	Audio_Stream *output;

	output = create_audiostream(16, 1, 44100, 1024);

	for (i = 0; i < 1024; i++) {
		output->samples[0][i] = 2.0 * (i % 2) - 1.0;
	}
	
	if (save_audiofile(output,"bar.wav") != OK ) {
		return ERROR;
	}
	free_audiostream(output);
	
	return OK;
}
